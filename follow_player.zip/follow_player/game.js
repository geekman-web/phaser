var game;
var gameOptions = {

    // player gravity
    playerGravity: 900,

    // player horizontal speed
    playerSpeed: 200,

}
window.onload = function() {
    var gameConfig = {
        type: Phaser.CANVAS,
        width: 640,
        height: 480,
        backgroundColor: 0x444444,
        physics: {
            default: "arcade",
            arcade: {
                gravity: {
                    y: 0
                }
            }
        },
       scene: [preloadGame, playGame]
    }
    game = new Phaser.Game(gameConfig);
}
class preloadGame extends Phaser.Scene{
    constructor(){
        super("PreloadGame");
    }
    preload(){
        this.load.tilemapTiledJSON("level", "Test_Map_1x1_walls.json");
        this.load.image("tile", "tile.png");
        this.load.image("hero", "player1.png");
        this.load.image("companion", "player2.png");
    }
    create(){
        this.scene.start("PlayGame");
    }
}
class playGame extends Phaser.Scene{
    constructor(){
        super("PlayGame");
    }
    create(){
        // creation of "level" tilemap
        this.map = this.make.tilemap({
            key: "level"
        });

        // adding tiles (actually one tile) to tilemap
        var tile = this.map.addTilesetImage("square 1x1", "tile");

        // tile 1 (the black tile) has the collision enabled
        this.map.setCollision(1);

        // which layer should we render? That's right, "layer01"
        this.layer = this.map.createStaticLayer("Tile Layer 1", tile);

        // adding the companion sprite and enabling ARCADE physics for the companion
        this.hero = this.physics.add.sprite(300, 370, "hero");
        this.companion = this.physics.add.sprite(1000, 370, "companion");
		
		this.cursors = this.input.keyboard.createCursorKeys();

        // set workd bounds to allow camera to follow the player
        this.cameras.main.setBounds(0, 0, 1920, 1440);

        // making the camera follow the player
        this.cameras.main.startFollow(this.hero);
    }
	
	controls () {

			if (this.cursors.right.isDown) {
				
				//If button wasn't pressed yet, do actions that you need once, then set to true(pressed)
				if(!this.isButtonDown) {
					this.hero.flipX = false;
					this.isButtonDown = true;
				}
				
				this.setPlayerXVelocity(true, this.hero);
				
			} else if (this.cursors.left.isDown) {
				
				if(!this.isButtonDown) {
					this.hero.flipX = true;
					this.isButtonDown = true;
				}
				
				this.setPlayerXVelocity(true, this.hero);
				
			} else {
				this.hero.body.velocity.x = 0;
				this.isButtonDown = false;
			}
		
	}
	
	tileCollision (character, layer) {
		
		// some temporary variables to determine if the player is blocked only once
            var blockedLeft = character.body.blocked.left;
            var blockedRight = character.body.blocked.right;
			
            // companion on the ground and touching a wall on the right
            if(blockedRight){

                // horizontal flipping companion sprite
                character.flipX = true;
				console.log("right wall");
            }

            // companion on the ground and touching a wall on the right
            if(blockedLeft){

                // default orientation of companion sprite
                character.flipX = false;
				console.log("left wall");
            }	
	}
	
	followPlayer () {
		
		var companionPos = this.companion.x;
		var distanceFromcompanion = 200;
		var fightRange = 20;
		if (this.hero.x >= companionPos-distanceFromcompanion && this.hero.x <= companionPos-20) {
			
			this.companion.flipX = true;
			this.setPlayerXVelocity(true, this.companion)
			
		} else if (this.hero.x >= companionPos-fightRange && this.hero.x <= companionPos+fightRange) {
			this.companion.body.velocity.x = 0;
		} else if (this.hero.x >= companionPos+fightRange && this.hero.x <= companionPos+distanceFromcompanion) {
				this.companion.flipX = false;
				this.setPlayerXVelocity(true, this.companion)
		}
	}
	
    update(){

        // set some default gravity values. Look at the function for more information
        this.setDefaultValues();
		this.followPlayer();


        this.physics.world.collide(this.companion, this.layer, function (companion, layer){
			// some temporary variables to determine if the player is blocked only once
            var blockedDown = companion.body.blocked.down;
            var blockedLeft = companion.body.blocked.left;
            var blockedRight = companion.body.blocked.right;
			
            // companion on the ground
            if(blockedDown){

                // companion can jump
                this.canJump = true;
            }

            // companion on the ground and touching a wall on the right
            if(blockedRight){
                // horizontal flipping companion sprite
                companion.flipX = true;
            }

            // companion on the ground and touching a wall on the right
            if(blockedLeft){

                // default orientation of companion sprite
                companion.flipX = false;
            }

            // companion NOT on the ground and touching a wall
            if((blockedRight || blockedLeft) && !blockedDown){

                // companion on a wall
                companion.scene.onWall = true;

                // remove gravity
                companion.body.gravity.y = 0;

                // setting new y velocity
                companion.body.velocity.y = gameOptions.playerGrip;
				//this.companion.play("walk", true);
            }
			
		}, null, this)
		
        this.physics.world.collide(this.hero, this.layer)

		this.controls();
    }

    setDefaultValues(){
        this.hero.body.gravity.y = gameOptions.playerGravity;
        this.companion.body.gravity.y = gameOptions.playerGravity;
        this.onWall = false;
    }

    // sets player velocity according to the direction it's facing, unless "defaultDirection"
    // is false, in this case multiplies the velocity by -1
    setPlayerXVelocity(defaultDirection, character){
        character.body.velocity.x = gameOptions.playerSpeed * (character.flipX ? -1 : 1) * (defaultDirection ? 1 : -1);
		//this.companion.play("walk", true);
    }
}
